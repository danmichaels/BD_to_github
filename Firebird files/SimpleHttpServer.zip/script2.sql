
connect 'Bank_term.FDB' user 'SYSDBA' password 'masterkey';

input test.sql;
commit;